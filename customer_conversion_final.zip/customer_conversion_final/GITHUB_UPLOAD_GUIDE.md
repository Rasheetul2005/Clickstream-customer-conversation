# GitHub Upload

1. Create a new GitHub repository named `customer-conversion-clickstream-ml`.
2. Extract this project ZIP.
3. Upload the project files/folders to the repository.
4. Commit changes.
5. For local testing:
   - `pip install -r requirements.txt`
   - `python src/01_download_and_prepare.py`
   - `python src/02_train_models.py`
   - `streamlit run app.py`
6. The README explains the target assumptions.
